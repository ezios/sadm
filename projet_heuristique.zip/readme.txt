#Mahaman bachir Attouman Ousmane
#Adediran Flore
#Ali Abakar
#Yves Fernand Nga Ngono


-ex�cutable sacado.exe 
    En ligne de commande se placer dans le repertoire de l'ex�cutable et utiliser 
    		sacado.exe [chemin du fichier instance] [fichier destination pour les resultat ] [temp execution]

-les codes sources
     -Sont en python 3
     - Il faut avoir numpy ( seul biblioth�que non native utilisee ) 
     - data.py d�pendance
     - pour executer en python :  python sacado.py [chemin du fichier instance] [fichier destination pour les resultat ] [temp execution
     